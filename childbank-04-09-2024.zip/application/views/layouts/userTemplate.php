﻿<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Dashboard-Childbank</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <!-- <link href="assets/img/favicon.png" rel="icon"> -->
    <!-- <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon"> -->

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="<?= base_url('assets/user/vendor/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">
    <link href="<?= base_url('assets/user/vendor/bootstrap-icons/bootstrap-icons.css') ?>" rel="stylesheet">
    <link href="<?= base_url('assets/user/vendor/boxicons/css/boxicons.min.css') ?>" rel="stylesheet">
    <link href="<?= base_url('assets/user/vendor/quill/quill.snow.css') ?>" rel="stylesheet">
    <link href="<?= base_url('assets/user/vendor/quill/quill.bubble.css') ?>" rel="stylesheet">
    <link href="<?= base_url('assets/user/vendor/remixicon/remixicon.css') ?>" rel="stylesheet">
    <link href="<?= base_url('assets/user/vendor/simple-datatables/style.css') ?>" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="<?= base_url('assets/user/css/style.css') ?>" rel="stylesheet">
    <link href="<?= base_url('assets/user/css/custom.css') ?>" rel="stylesheet">

    <!-- jquery files -->
    <script src="<?= base_url('assets/user/js/jquery-3.6.3.min.js') ?>"></script>
    <script src="<?= base_url('assets/user/js/jquery.validate.min.js') ?>"></script>

</head>

<body>


    <!-- ======= Header ======= -->
    <header id="header" class="header container fixed-top d-flex align-items-center">

        <div class="d-flex align-items-center justify-content-between">

            <!-- <i class="bi bi-list toggle-sidebar-btn d-flex align-items-center"></i> -->
            <a href="<?= base_url() ?>" class="logo ">
                <img src="<?= base_url('assets/user/img/logo.jpeg') ?>" alt="">
                <!-- <span class="d-none d-lg-block">NiceAdmin</span> -->
            </a>
        </div><!-- End Logo -->


        <nav class="header-nav w-100">
            <ul class="d-flex align-items-center justify-content-between">


                <ul class="nav nav-pills ms-5" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">My Account</button>
                    </li>
                    <?php
                    if ($this->session->userdata('userType') == 'parent') { ?>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-childern-tab" data-bs-toggle="pill" data-bs-target="#pills-childern" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">My Children</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-request-tab" data-bs-toggle="pill" data-bs-target="#pills-request" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">My Children Requests</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-parentlog-tab" data-bs-toggle="pill" data-bs-target="#pills-parentlog" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Notification</button>
                        </li>

                    <?php } else { ?>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-myrequest-tab" data-bs-toggle="pill" data-bs-target="#pills-myrequest" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">My Requests</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-goal-tab" data-bs-toggle="pill" data-bs-target="#pills-goal" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Saving Goals</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-store-tab" data-bs-toggle="pill" data-bs-target="#pills-store" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Store</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-childlog-tab" data-bs-toggle="pill" data-bs-target="#pills-childlog" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Notification</button>
                        </li>

                        <!--<li class="nav-item" role="presentation">-->
                        <!--    <button class="nav-link" id="pills-cart-tab" data-bs-toggle="pill" data-bs-target="#pills-cart" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Cart</button>-->
                        <!--</li>-->


                    <?php } ?>
                </ul>



                <li class="nav-item dropdown pe-3">

                    <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                        <!-- <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle"> -->
                        <span class="d-none d-md-block dropdown-toggle ps-2"><?= $this->session->userdata('firstName').' '. $this->session->userdata('lastName') ?></span>
                    </a><!-- End Profile Iamge Icon -->

                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                        
                    <li>
                            <a class="dropdown-item d-flex align-items-center" data-bs-toggle="modal" data-bs-target="#updateProfileModal" onclick="getLoggedInUser()">
                                <i class=""></i>
                                <span>Profile</span>
                            </a>
                        </li>
                
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                      
                        <li>
                            <a id="signout" class="dropdown-item d-flex align-items-center pointer-cursor" href="<?= base_url('logout') ?>">
                                <i class=""></i>
                                <span>Sign Out</span>
                            </a>
                        </li>

                    </ul><!-- End Profile Dropdown Items -->
                </li><!-- End Profile Nav -->

            </ul>
        </nav><!-- End Icons Navigation -->

    </header><!-- End Header -->




    <main id="main" class="main">

        <section class="section container">

            <?= $template['body']; ?>


        </section>

    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer container">
        <div class="copyright">
            &copy; Copyright <strong><span>Childbank</span></strong>. All Rights Reserved
        </div>
        <div class="credits">

        </div>
    </footer><!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="<?= base_url('assets/user/vendor/apexcharts/apexcharts.min.js') ?>"></script>
    <script src="<?= base_url('assets/user/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
    <script src="<?= base_url('assets/user/vendor/chart.js/chart.umd.js') ?>"></script>
    <script src="<?= base_url('assets/user/vendor/echarts/echarts.min.js') ?>"></script>
    <script src="<?= base_url('assets/user/vendor/quill/quill.js') ?>"></script>
    <script src="<?= base_url('assets/user/vendor/simple-datatables/simple-datatables.js') ?>"></script>
    <script src="<?= base_url('assets/user/vendor/tinymce/tinymce.min.js') ?>"></script>
    <script src="<?= base_url('assets/user/vendor/php-email-form/validate.js') ?>"></script>

    <!-- Template Main JS File -->
    <script src="<?= base_url('assets/user/js/main.js') ?>"></script>



    <!--change password  modal end-->
    <!-- start alert Modal -->
    <!-- Trigger the modal with a button -->
    <button type="button" class="btn btn-info btn-lg" data-bs-toggle="modal" data-bs-target="#alertModalSuccess" id="alertSuccess" style="display:none;">success</button>

    <div id="alertModalSuccess" class="modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">

            <!-- Modal content-->
            <div class="modal-content ">
                <div class="modal-header">
                    <h4 class="modal-title">Notification</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body bg-success">
                    <p id="notification" class="notification text-white"></p>
                </div>
                <!--                    <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Ok</button>
                                        </div>-->
            </div>

        </div>
    </div>

    <!--end alert modal-->



    <!-- Trigger the modal with a button  danger-->
    <button type="button" class="btn btn-info btn-lg" data-bs-toggle="modal" data-bs-target="#alertModalDanger" id="alertDanger" style="display:none;">danger</button>

    <div id="alertModalDanger" class="modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                <h4 class="modal-title">Notification</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                   
                </div>
                <div class="modal-body bg-danger">
                    <p id="notification" class="notification text-white"></p>
                </div>
                <!--                    <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Ok</button>
                                </div>-->
            </div>

        </div>
    </div>

    <!--end alert modal-->


    <!-- login modal start -->



    <div id="updateProfileModal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">

            <!-- Modal content-->
            <div class="modal-content ">
                <div class="modal-header bg-sea-green">
                <h4 class="modal-title  text-white fw-bold">Update Profile</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    
                </div>
                <div class="modal-body">
                    <!-- Login Form -->
                    <form id="updateProfile">

                        <input type="hidden" name="id" id="id" />
                        <input type="hidden" name="userType" id="userType" />
                        <div class="col-12">
                            <label for="yourName" class="form-label">First Name*</label>
                            <input type="text" name="firstName" id="firstName" class="form-control">
                            <div class="invalid-feedback">Please, enter your name!</div>
                        </div>

                        <div class="col-12">
                            <label for="yourEmail" class="form-label">Last Name*</label>
                            <input type="text" name="lastName" id="lastName" class="form-control">
                            <div class="invalid-feedback">Please enter a valid Email adddress!</div>
                        </div>

                        
                        <div class="col-12">
                            <label for="yourEmail" class="form-label">ID*</label>
                            <input type="text" name="userName" id="userName" class="form-control">
                            <div class="invalid-feedback">Please enter a valid Email adddress!</div>
                        </div>

                        <div class="col-12">
                            <label for="yourPassword" class="form-label">Password*</label>
                            <input type="password" name="pass" id="pass" class="form-control">
                            <span class="txt-gray">Password must contain 6 characters at least one uppercase letter, one lowercase letter, and one special character.</span>
                            <div class="invalid-feedback">Please enter your password!</div>
                        </div>

                        <div class="col-12">
                            <label for="yourPassword" class="form-label">Confirm Password*</label>
                            <input type="password" name="confirmPass" class="form-control" >
                            <div class="invalid-feedback">Please enter your password!</div>
                        </div>

                        <div class="col-12">
                            <label for="yourPassword" class="form-label">DOB*</label>
                            <input type="date" name="dob" id="dob" class="form-control">
                            <span class="txt-gray">Parent age should be greater than 18 years and child age should be between 6 to 13 years old.</span>
                            <div class="invalid-feedback">Please enter your password!</div>
                        </div>


                        <!-- <div class="col-12">
                            <label for="yourPassword" class="form-label">Email*</label>
                            <input type="email" name="email" id="email" class="form-control">
                            <div class="invalid-feedback">Please enter your password!</div>
                        </div>-->

                        <div class="col-12" id="divShippingAddress" style="display: none;">
                            <label for="yourPassword" class="form-label">Shipping Address*</label>
                            <input type="text" name="shippingAddress" id="shippingAddress" class="form-control">
                            <div class="invalid-feedback">Please enter your password!</div>
                        </div> 


                        <div class="col-12  mt-5 ">
                            <button class="btn btn-primary bg-sea-green w-100 login-btn" type="button" onclick="updateProfile();">Update</button>

                        </div>

                        <div class="form-group errorDiv" style="display:none;color:brown;" id="errorDiv">
                            <p id="error" class="error"></p>
                        </div>
                    </form>
                    <!-- /Login Form -->
                </div>
                <!--                    <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Ok</button>
                                        </div>-->
            </div>

        </div>
    </div>


    <!-- login modal end -->


</body>

</html>

<script type="text/javascript">
    $(document).ready(function() {
        // remove local storage on sign out 
        $('#signout').on('click', function() {
            localStorage.removeItem('lastClickedTab');
        });
        getLoggedInUser();
    });


    function getLoggedInUser() {

        var url = "<?php echo base_url('user/User/getLoggedInUser'); ?>";
        $.ajax({
            url: url,
            type: "POST",
            success: function(response) {
                try {
                    response = JSON.parse(response);
                    $('#updateProfile #id').val(response['id']);
                    $('#updateProfile #userType').val(response['userType']);
                    $('#updateProfile #firstName').val(response['firstName']);
                    $('#updateProfile #lastName').val(response['lastName']);
                    $('#updateProfile #dob').val(response['dob']);
                    $('#updateProfile #userName').val(response['userName']);
                    // $('#updateProfile #email').val(response['email']);

if(response['userType']=="child")
$("#divShippingAddress").show();

                     $('#updateProfile #shippingAddress').val(response['shippingAddress']);


                    $('#checkout #id').val(response['id']);
                    $('#checkout #firstName').val(response['firstName']);
                    $('#checkout #lastName').val(response['lastName']);
                    $('#checkout #dob').val(response['dob']);
                    $('#checkout #userName').val(response['userName']);
                    // $('#checkout #email').val(response['email']);
                    $('#checkout #shippingAddress').val(response['shippingAddress']);




                } catch (e) {
                    alert(e);
                }
            },
            error: function(e) {
                alert('System Error !');
            }
        });
    }

    function updateProfile() {


        $.validator.addMethod("passwordCheck", function(value, element) {
        return this.optional(element) 
            || /[A-Z]/.test(value)    // at least one uppercase letter
            && /[a-z]/.test(value)    // at least one lowercase letter
            && /[!@#$%^&*(),.?":{}|<>]/.test(value); // at least one special character
    }, "Password must contain at least one uppercase letter, one lowercase letter, and one special character.");


    $.validator.addMethod("ageCheck", function(value, element) {
        var userType = $("input[name='userType']").val();
        var dob = new Date(value);
        var today = new Date();
        var age = today.getFullYear() - dob.getFullYear();
        var month = today.getMonth() - dob.getMonth();

        if (month < 0 || (month === 0 && today.getDate() < dob.getDate())) {
            age--;
        }

        if (userType === 'parent') {
            return age >= 18;
        } else if (userType === 'child') {
            return age >= 6 && age <= 13;
        }
        return true;
    }, function(params, element) {
        var userType = $("input[name='userType']").val();
        if (userType === 'parent') {
            return "You must be at least 18 years old.";
        } else if (userType === 'child') {
            return "Age must be between 6 and 13 years.";
        }
    });

        var form = $('#updateProfile').validate({
            rules: {

                fisrtName: {
                    required: true
                },
                lastName: {
                    required: true
                },
                dob: {
                    required: true,
                    ageCheck:true

                },
                pass: {
                    maxlength: 20,
                    minlength: 6,
                    passwordCheck: true
                },
                confirmPass: {
                    equalTo: "#pass"

                },
                userName: {
                    required:true,
                    maxlength: 10,
                    minlength: 10,
                    number:true
                }
                // ,
                // email: {
                //     email: true,
                //     required:true
                // }
                ,
         shippingAddress: {
          required: function() {
                return $("input[name='userType']").val() === "child";
            }
          }

            }
            ,
      messages: {
        confirmPass: "Password didn't match.",
        pattern: "Password must contain at least one uppercase letter, one lowercase letter, and one special character."
      }

        });
        //#store the validator obj
        if ($('#updateProfile').valid()) {

            // submit using ajax
            var url = "<?php echo base_url('user/User/updateProfile'); ?>";
            var formData = new FormData($("#updateProfile")[0]);

            $.ajax({
                url: url,
                type: "POST",
                data: formData,
                async: false,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    try {
                        response = JSON.parse(response);

                        if (response.status == '1') {

                            $('#updateProfile #errorDiv').css("display", "none");
                            $('#btnClose').trigger('click');
                            $('#alertSuccess').trigger('click');
                            $('#updateProfile')[0].reset();

                            setTimeout(function() {
                                $('#alertModalSuccess').modal('hide');

                            }, 2000);

                        } else {
                            $('#updateProfile #errorDiv').css("display", "block");
                            $('#updateProfile #error').text(response.message);
                        }

                        $('.notification').text(response.message);

                    } catch (e) {
                        alert(e);
                    }
                },
                error: function(e) {
                    alert('System Error !');
                }
            });
        } else {
            form.focusInvalid();

        }

    }


    $('#login input').keypress(function(event) {
        if (event.keyCode === 13) {
            event.preventDefault();
            login();
        }
    });
    
</script>

</html>