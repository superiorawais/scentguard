<?php

Defined('BASEPATH') or exit('No direct script access allowed');

class User_model extends CI_Model
{

    public function signUp($data)
    {

        $userName = $data['userName'];
        $this->db->where('userName', $userName);
        $query = $this->db->get('user');
        if ($query->num_rows() > 0) {
            return array("message" => "ID Already Exists.", "status" => "0");
        }
        $data = array(
            'firstName' => ucfirst($data['firstName']),
            'lastName' => ucfirst($data['lastName']),
            'userName' => $data['userName'],
            'pass' => md5($data['pass']),
            'dob' => $data['dob'],
            'userType' => $data['userType'],
            // 'email' => $data['email'],
             'shippingAddress' => isset($data['shippingAddress'])?$data['shippingAddress']:''
        );

        $this->db->insert('user', $data);
        if ($this->db->affected_rows() > 0) {
            return array("message" => "You are Successfully registered.", "status" => "1");
        } else {
            return array("message" => "Registration failed. Please try again.", "status" => "0");
        }
    }

    public function addMoney($data)
    {
        $childId = $data['childId'];
        $amountToAdd = $data['amount'];
        $parentId = $this->session->userdata('id');

        // Start transaction
        $this->db->trans_start();

        // Fetch child balance
        $this->db->select('balance');
        $this->db->where('id', $childId);
        $query = $this->db->get('user');

        if ($query->num_rows() > 0) {
            $result = $query->row_array();
            $currentChildBalance = $result['balance'];
            $newChildBalance = $currentChildBalance + $amountToAdd;

            // Fetch parent balance
            $this->db->select('balance');
            $this->db->where('id', $parentId);
            $parentQuery = $this->db->get('user');

            if ($parentQuery->num_rows() > 0) {
                $parentResult = $parentQuery->row_array();
                $currentParentBalance = $parentResult['balance'];

                // Check if the parent has sufficient balance
                if ($currentParentBalance >= $amountToAdd) {
                    $newParentBalance = $currentParentBalance - $amountToAdd;

                    // Update child's balance
                    $this->db->where('id', $childId);
                    $this->db->update('user', array('balance' => $newChildBalance));

                    // Update parent's balance
                    $this->db->where('id', $parentId);
                    $this->db->update('user', array('balance' => $newParentBalance));

                    if ($this->db->trans_status() === FALSE) {
                        // Rollback transaction if anything failed
                        $this->db->trans_rollback();
                        return array("message" => "Failed to update balance.", "status" => "0");
                    } else {

                        if ($this->addTransactionLog($childId, $parentId, $amountToAdd, 'Add Money'))
                            // Commit transaction if all updates were successful
                            $this->db->trans_commit();
                        return array("message" => "Balance updated successfully.", "status" => "1");
                    }
                } else {
                    // Rollback if the parent doesn't have sufficient balance
                    $this->db->trans_rollback();
                    return array("message" => "Insufficient balance in parent's account.", "status" => "0");
                }
            } else {
                // Rollback if the parent is not found
                $this->db->trans_rollback();
                return array("message" => "Parent not found.", "status" => "0");
            }
        } else {
            return array("message" => "Child not found.", "status" => "0");
        }
    }

    public function addGoal($data)
    {
        // Get the child ID from session
        $childId = $this->session->userdata('id');
        
        // Check if the user exists in the child table
        $this->db->select('id');
        $this->db->from('child');
        $this->db->where('childId', $childId);
        $query = $this->db->get();
    
        if ($query->num_rows() == 0) {
            // If no rows are found, return an error message
            return array("message" => "You are not related to any parent,so you can't create goal", "status" => "0");
        }
    
        // Prepare data for insertion
        $goalData = array(
            'name' => $data['name'],
            'targetAmount' => $data['targetAmount'],
            'childId' => $childId,
            'startDate' => $data['startDate'],
            'endDate' => $data['endDate'],
            'goalPlanType' => $data['goalPlanType']
        );
    
        // Insert the goal data into the 'goal' table
        $this->db->insert('goal', $goalData);
    
        // Check if the insert was successful
        if ($this->db->affected_rows() > 0) {
            return array("message" => "Goal successfully added.", "status" => "1");
        } else {
            return array("message" => "Failed to add goal.", "status" => "0");
        }
    }
    

    public function getUserById($userId)
    {
        // Get user data
        $this->db->where('id', $userId);
        $query = $this->db->get('user');

        if ($query->num_rows() > 0) {
            $userData = $query->row_array();


            $this->db->where('parentId', $userId);
            $cardQuery = $this->db->get('card');

            if ($cardQuery->num_rows() > 0) {
                $cardData = $cardQuery->result_array();
                // Add card data to user data
                $userData['card'] = $cardData;
            } else {
                $userData['card'] = []; // No card data found
            }

            return $userData;
        } else {
            return null;
        }
    }


    public function updateRequestStatus($data)
    {
        $requestId = $data['requestId'];
        $status = $data['status'];
        $userType = $this->session->userdata('userType'); // Fetch the userType from the session

        $this->db->trans_start();

        // Fetch the request details
        $this->db->select('childId, parentId, amount, requestType');
        $this->db->where('id', $requestId);
        $query = $this->db->get('request');

        if ($query->num_rows() > 0) {
            $request = $query->row_array();
            $childId = $request['childId'];
            $parentId = $request['parentId'];
            $amount = $request['amount'];
            $requestType = $request['requestType'];

            if ($status == 2 && $requestType == 'money') {
                // Fetch the parent's balance
                $this->db->select('balance');
                $this->db->where('id', $parentId);
                $parentQuery = $this->db->get('user');

                if ($parentQuery->num_rows() > 0) {
                    $parentBalance = $parentQuery->row()->balance;

                    if ($parentBalance >= $amount) {
                        // Deduct amount from parent's balance
                        $this->db->set('balance', 'balance - ' . $this->db->escape($amount), FALSE);
                        $this->db->where('id', $parentId);
                        $this->db->update('user');

                        // Add amount to child's balance
                        $this->db->set('balance', 'balance + ' . $this->db->escape($amount), FALSE);
                        $this->db->where('id', $childId);
                        $this->db->update('user');

                        // Update request status to approved
                        $this->db->set('status', 2);
                        $this->db->where('id', $requestId);
                        $this->db->update('request');
     // Execute the transactionLog function
     $this->addTransactionLog($childId, $parentId, $amount,"Money Request");



                    } else {
                        $this->db->trans_rollback();
                        return array("message" => "Parent does not have sufficient balance.", "status" => "0");
                    }
                } else {
                    $this->db->trans_rollback();
                    return array("message" => "Parent not found.", "status" => "0");
                }
            } elseif ($status == 3) {
                // If status is 3, just update the request status
                $this->db->set('status', 3);
                $this->db->where('id', $requestId);
                $this->db->update('request');
            } elseif ($status == 4 && $userType == 'child') {
                // Fetch the child's balance
                $this->db->select('balance');
                $this->db->where('id', $childId);
                $childQuery = $this->db->get('user');

                if ($childQuery->num_rows() > 0) {
                    $childBalance = $childQuery->row()->balance;

                    if ($childBalance >= $amount) {
                        // Deduct amount from child's balance
                        $this->db->set('balance', 'balance - ' . $this->db->escape($amount), FALSE);
                        $this->db->where('id', $childId);
                        $this->db->update('user');

                        // Update request status to 4
                        $this->db->set('status', 4);
                        $this->db->where('id', $requestId);
                        $this->db->update('request');

                        $this->addTransactionLog($childId, $parentId, $amount, "Make Purchase");


                    } else {
                        $this->db->trans_rollback();
                        return array("message" => "Child does not have sufficient balance.", "status" => "0");
                    }
                } else {
                    $this->db->trans_rollback();
                    return array("message" => "Child not found.", "status" => "0");
                }
            } else {
                // If status is not 2, 3, or 4, just update the request status
                $this->db->set('status', $status);
                $this->db->where('id', $requestId);
                $this->db->update('request');
            }

            if ($this->db->trans_status() === FALSE) {
                $this->db->trans_rollback();
                return array("message" => "Failed to update request status.", "status" => "0");
            } else {
               
                $this->db->trans_commit();
                return array("message" => "Request status updated successfully.", "status" => "1");
            }
        } else {
            $this->db->trans_rollback();
            return array("message" => "Request not found.", "status" => "0");
        }
    }

    public function deleteCard($data)
    {
        // Extract the cardId from the data array
        $cardId = $data['cardId'];

        // Check if the cardId is provided
        if (!isset($cardId)) {
            return array("message" => "Card ID not provided.", "status" => "0");
        }

        // Delete the card from the card table
        $this->db->where('id', $cardId);
        $this->db->delete('card');

        // Check if the deletion was successful
        if ($this->db->affected_rows() > 0) {
            return array("message" => "Card deleted successfully.", "status" => "1");
        } else {
            return array("message" => "Failed to delete card or card not found.", "status" => "0");
        }
    }


    public function getLoggedInUser()
    {
        $userId = $this->session->userdata('id');

        if (!$userId) {
            return null;
        }

        $query = $this->db->get_where('user', array('id' => $userId));

        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return null;
        }
    }

    public function getRequestsByParentId($parentId)
    {
        $this->db->select('request.*, user.firstName, user.lastName, user.userName');
        $this->db->from('request');
        $this->db->join('user', 'request.childId = user.id');
        $this->db->where('request.parentId', $parentId);
        $this->db->order_by('id', 'desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }

    public function getTransactionLogByParentId($parentId)
    {
        // Select the required fields from transactionlog and user tables
        $this->db->select('transactionlog.*, user.userName as childId, user.firstName,user.lastName');
        $this->db->from('transactionlog');

        // Join the user table on the childId
        $this->db->join('user', 'transactionlog.childId = user.id', 'left');

        // Filter the results by parentId
        $this->db->where('transactionlog.parentId', $parentId);
        $this->db->order_by('id', 'desc');

        // Execute the query
        $query = $this->db->get();

        // Check if any rows are returned
        if ($query->num_rows() > 0) {
            // Return the result as an array of objects
            return $query->result_array();
        } else {
            // Return an empty array if no records found
            return array();
        }
    }

    public function getTransactionLogByChildId($childId)
    {
        // Select the required fields from transactionlog and user tables
        $this->db->select('transactionlog.*, user.userName as parentId, user.firstName,user.lastName');
        $this->db->from('transactionlog');

        // Join the user table on the childId
        $this->db->join('user', 'transactionlog.parentId = user.id', 'left');

        // Filter the results by parentId
        $this->db->where('transactionlog.childId', $childId);
        $this->db->order_by('id', 'desc');
        // Execute the query
        $query = $this->db->get();

        // Check if any rows are returned
        if ($query->num_rows() > 0) {
            // Return the result as an array of objects
            return $query->result_array();
        } else {
            // Return an empty array if no records found
            return array();
        }
    }

    public function checkout($data)
    {
        $childId = $this->session->userdata('id');

        // Fetch parentId from the database using the childId
        $query = $this->db->select('parentId')
            ->from('child')
            ->where('childId', $childId)
            ->get();

        $result = $query->row();
        if ($result) {
            $parentId = $result->parentId;
        } else {
            return array("message" => "Parent not found.", "status" => "0");
        }

        // Initialize total price
        $totalPrice = 0;
        $totalAmount = 0;
        $orderNumber = uniqid('order_');

        // Calculate total price from the cart array
        foreach ($data as $item) {
            $itemAmount = $item['productPrice'] * $item['quantity'];
            $totalPrice += $itemAmount;
        }

        // Check if total price is greater than 50
        if ($totalPrice > 50) {

            // Insert each product into the request table and orderDetail table
            foreach ($data as $item) {
                $itemAmount = $item['productPrice'] * $item['quantity'];
                $totalAmount += $itemAmount;

                // Insert into orderDetail table
                $this->db->insert('orderDetail', [
                    'orderNumber' => $orderNumber,
                    'productId' => $item['productId'],
                    'quantity' => $item['quantity'],
                    'price' => $item['productPrice'],
                    'amount' => $itemAmount,
                ]);
            }

            // Insert into request table
            $this->db->insert('request', [
                'parentId' => $parentId,
                'childId' => $childId,
                'amount' => $totalAmount,
                'requestType' => 'purchase',
                'orderNumber' => $orderNumber // Add order number reference
            ]);

            $this->session->unset_userdata('cart');
            return array("message" => "Request successfully sent to parent. Total amount: " . $totalAmount, "status" => "1");
        } else {
            // Fetch the current balance of the child
            $query = $this->db->select('balance')
                ->from('user')
                ->where('id', $childId)
                ->get();

            $result = $query->row();
            if ($result) {
                $currentBalance = $result->balance;

                // Check if the child has sufficient balance
                if ($currentBalance >= $totalPrice) {
                    // Deduct total price from child's balance
                    $newBalance = $currentBalance - $totalPrice;

                    // Update child's balance in the database
                    $this->db->where('id', $childId)
                        ->update('user', ['balance' => $newBalance]);

                    // Insert into orderDetail table
                    foreach ($data as $item) {
                        $itemAmount = $item['productPrice'] * $item['quantity'];
                        $this->db->insert('orderDetail', [
                            'orderNumber' => $orderNumber,
                            'productId' => $item['productId'],
                            'quantity' => $item['quantity'],
                            'price' => $item['productPrice'],
                            'amount' => $itemAmount,
                        ]);
                    }

                    // Insert into request table with directPurchase=1
                    $this->db->insert('request', [
                        'parentId' => $parentId,
                        'childId' => $childId,
                        'amount' => $totalPrice,
                        'requestType' => 'purchase',
                        'orderNumber' => $orderNumber, // Add order number reference
                        'directPurchase' => 1,
                        'status' => 4 // Add directPurchase parameter
                    ]);
                   

                    $this->addTransactionLog($childId, $parentId, $totalPrice, "Make Purchase");
                    $this->session->unset_userdata('cart');
                    return array("message" => "Balance updated and request processed successfully. Total amount: " . $totalPrice, "status" => "1");
                } else {
                    return array("message" => "Insufficient balance.", "status" => "0");
                }
            } else {
                return array("message" => "No balance found.", "status" => "0");
            }
        }
    }

    public function getOrderDetailByOrderNumber($data)

    {
        $orderNum = $data['orderNum'];
        // Query to fetch order details with product names
        $this->db->select('orderDetail.productId, product.name, orderDetail.quantity, orderDetail.price')
            ->from('orderDetail')
            ->join('product', 'orderDetail.productId = product.id')
            ->where('orderDetail.orderNumber', $orderNum);

        $query = $this->db->get();

        // Check if order details exist
        if ($query->num_rows() > 0) {
            return $query->result_array(); // Return the result as an array
        } else {
            return array();
        }
    }

    public function getReminders($childId)
    {
        $this->db->select('goal.name, reminder.*, COUNT(reminder.isRead = 0 OR NULL) AS unread_count');
        $this->db->from('goal');
        $this->db->join('reminder', 'reminder.goalId = goal.id', 'inner'); // Use 'inner' join to fetch only goals with reminders
        $this->db->where('goal.childId', $childId);
        $this->db->group_by('goal.id'); // Group by goal.id to avoid duplicate rows
        $this->db->order_by('reminder.id', 'desc');
    
        $query = $this->db->get();
    
        // Return the result as an array
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }
    

    public function updateReminderStatus()
    {
        // Prepare the data for update
        $data = array(
            'isRead' => 1
        );
    
        // Update all rows in the reminder table
        $this->db->update('reminder', $data);
    
        // Check if the query was successful
        if ($this->db->affected_rows() > 0) {
            return array("message" => "Reminder Status successfully updated.", "status" => "1");
        } else {
            return array("message" => "Request failed", "status" => "0");
        }
    }
    




    public function getProductById($productId)
    {
        $this->db->select('id, name, price,image');
        $this->db->from('product');
        $this->db->where('id', $productId);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return false;
        }
    }

    public function getRequestsByChildId($childId)
    {
        $this->db->select('request.*, user.firstName, user.lastName, user.userName');
        $this->db->from('request');
        $this->db->join('user', 'request.childId = user.id', 'left');
        $this->db->where('request.childId', $childId);
        $this->db->order_by('id', 'desc');

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }

    public function addGoalMoney($data)
    {
        $goalId = $data['goalId'];
        $additionalGoalAmount = $data['amount'];

        $this->db->trans_start();
        $this->db->select('goalAmount');
        $this->db->where('id', $goalId);
        $query = $this->db->get('goal');

        if ($query->num_rows() > 0) {
            $currentGoalAmount = $query->row()->goalAmount;
            $newGoalAmount = $currentGoalAmount + $additionalGoalAmount;
            $userId = $this->session->userdata('id');
            $this->db->select('balance');
            $this->db->where('id', $userId);
            $userQuery = $this->db->get('user');

            if ($userQuery->num_rows() > 0) {
                $userBalance = $userQuery->row()->balance;

                if ($userBalance >= $additionalGoalAmount) {
                    $this->db->set('goalAmount', $newGoalAmount);
                    $this->db->set('updatedDate', date('Y-m-d H:i:s'));
                    $this->db->where('id', $goalId);
                    $this->db->update('goal');

                    $this->db->set('balance', 'balance - ' . $this->db->escape($additionalGoalAmount), FALSE);
                    $this->db->where('id', $userId);
                    $this->db->update('user');

                    if ($this->db->trans_status() === FALSE) {
                        $this->db->trans_rollback();
                        return array("message" => "Failed to update goal or update balance.", "status" => "0");
                    } else {
                        $this->db->trans_commit();
                        return array("message" => "Goal successfully updated and balance adjusted.", "status" => "1");
                    }
                } else {
                    $this->db->trans_rollback();
                    return array("message" => "Insufficient balance.", "status" => "0");
                }
            } else {
                $this->db->trans_rollback();
                return array("message" => "User not found.", "status" => "0");
            }
        } else {
            return array("message" => "Goal not found.", "status" => "0");
        }
    }

    public function requestMoney($data)
    {
        $childId = $this->session->userdata('id');
        $amount = $data['amount'];

        $this->db->select('parentId');
        $this->db->where('childId', $childId);
        $query = $this->db->get('child');

        if ($query->num_rows() > 0) {
            $result = $query->row_array();
            $parentId = $result['parentId'];

            $dataToInsert = array(
                'childId' => $childId,
                'parentId' => $parentId,
                'amount' => $amount,
                'requestType' => 'money'
            );

            $this->db->insert('request', $dataToInsert);

            if ($this->db->affected_rows() > 0) {
                return array("message" => "Request successfully created.", "status" => "1");
            } else {
                return array("message" => "Failed to create request.", "status" => "0");
            }
        } else {
            return array("message" => "You are not related with parent so you can't request money", "status" => "0");
        }
    }

    public function addParentMoney($data)
    {
        $parentId = $this->session->userdata('id');
        $amountToAdd = $data['amount'];

        $this->db->select('balance');
        $this->db->where('id', $parentId);
        $query = $this->db->get('user');

        if ($query->num_rows() > 0) {
            $result = $query->row_array();
            $currentBalance = $result['balance'];

            $newBalance = $currentBalance + $amountToAdd;

            $this->db->where('id', $parentId);
            $this->db->update('user', array('balance' => $newBalance));

            if ($this->db->affected_rows() > 0) {
                $this->session->set_userdata('balance', $newBalance);
                return array("message" => "Balance updated successfully.", "status" => "1");
            } else {
                return array("message" => "Failed to update balance.", "status" => "0");
            }
        } else {
            return array("message" => "Parent not found.", "status" => "0");
        }
    }

    public function addCard($data)
    {
        // Get the userId from the session
        $parentId = $this->session->userdata('id');

        // Check if a card entry already exists for the userId
        $this->db->where('parentId', $parentId);
        $existingCard = $this->db->get('card')->row_array();

        if ($existingCard) {
            // If an entry exists, update the card details
            $this->db->where('parentId', $parentId);
            $updateStatus = $this->db->update('card', [
                'cardNumber' => $data['cardNumber'],
                'cardCVC'    => $data['cardCVC'],
                'cardHolderName'    => $data['cardHolderName'],
                'expiryDate'    => $data['expiryDate']
            ]);

            if ($updateStatus) {
                return array("message" => "Card details updated successfully.", "status" => "1");
            } else {
                return array("message" => "Failed to update card details.", "status" => "0");
            }
        } else {
            // If no entry exists, insert a new record
            $insertStatus = $this->db->insert('card', [
                'parentId'   => $parentId,
                'cardNumber' => $data['cardNumber'],
                'cardCVC'    => $data['cardCVC'],
                'cardHolderName'    => $data['cardHolderName'],
                'expiryDate'    => $data['expiryDate']
            ]);

            if ($insertStatus) {
                return array("message" => "Card details added successfully.", "status" => "1");
            } else {
                return array("message" => "Failed to add card details.", "status" => "0");
            }
        }
    }


    public function withdrawMoney($data)
    {
        $childId = $data['childId'];
        $amountToWithdraw = $data['amount'];
        $parentId = $this->session->userdata('id');

        $this->db->trans_start();

        $this->db->select('balance');
        $this->db->where('id', $childId);
        $query = $this->db->get('user');

        if ($query->num_rows() > 0) {
            $result = $query->row_array();
            $currentBalance = $result['balance'];

            if ($currentBalance >= $amountToWithdraw) {
                $newChildBalance = $currentBalance - $amountToWithdraw;

                $this->db->where('id', $childId);
                $this->db->update('user', array('balance' => $newChildBalance));

                $this->db->select('balance');
                $this->db->where('id', $parentId);
                $parentQuery = $this->db->get('user');

                if ($parentQuery->num_rows() > 0) {
                    $parentResult = $parentQuery->row_array();
                    $currentParentBalance = $parentResult['balance'];

                    $newParentBalance = $currentParentBalance + $amountToWithdraw;
                    $this->db->where('id', $parentId);
                    $this->db->update('user', array('balance' => $newParentBalance));

                    if ($this->db->trans_status() === FALSE) {
                        $this->db->trans_rollback();
                        return array("message" => "Failed to update balance.", "status" => "0");
                    } else {

                        if ($this->addTransactionLog($childId, $parentId, $amountToWithdraw, 'Withdraw Money'))

                            $this->db->trans_commit();
                        return array("message" => "Balance updated successfully.", "status" => "1");
                    }
                } else {
                    $this->db->trans_rollback();
                    return array("message" => "Parent not found.", "status" => "0");
                }
            } else {
                return array("message" => "Insufficient balance.", "status" => "0");
            }
        } else {
            return array("message" => "Child not found.", "status" => "0");
        }
    }

    public function addChild($data)
    {
        $userName = $data['userName'];

        $this->db->select('id');
        $this->db->where('userName', $userName);
        $this->db->where('userType', 'child');
        $query = $this->db->get('user');

        if ($query->num_rows() > 0) {
            $result = $query->row_array();

            $this->db->select('childId');
            $this->db->where('childId', $result['id']);
            $query_1 = $this->db->get('child');

            if ($query_1->num_rows() > 0) {

                return array("message" => "Child already adopted by someone.", "status" => "0");
            }
        } else {
            return array("message" => "Invalid Child Id", "status" => "0");
        }

        $data = array(
            'childId' => $result['id'],
            'parentId' => $this->session->userdata('id')
        );

        $this->db->insert('child', $data);
        if ($this->db->affected_rows() > 0) {
            return array("message" => "Child Successfully Added.", "status" => "1");
        } else {
            return array("message" => "Add failed. Please try again.", "status" => "0");
        }
    }


    public function addTransactionLog($childId, $parentId, $amount, $transactionType)
    {
        // Prepare the data to insert into the transactionlog table
        $data = array(
            'childId' => $childId,
            'parentId' => $parentId,
            'amount' => $amount,
            'transactionType' => $transactionType
        );

        // Insert the data into the transactionlog table
        $this->db->insert('transactionlog', $data);

        // Check if the insert was successful
        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function login($data)
    {
        $userName = $data['userName'];
        $userType = $data['userType'];
        $pass = md5($data['pass']);

        $this->db->where('(userName = "' . $userName . '")');
        $this->db->where('pass', $pass);
        $this->db->where('userType', $userType);
        $this->db->where('status', '1');
        $query = $this->db->get('user');

        if ($query->num_rows() > 0) {
            $result = $query->row_array();
            $this->session->set_userdata('id', $result['id']);
            $this->session->set_userdata('firstName', $result['firstName']);
            $this->session->set_userdata('lastName', $result['lastName']);
            $this->session->set_userdata('userType', $result['userType']);
            $this->session->set_userdata('pass', $result['pass']);
            $this->session->set_userdata('balance', $result['balance']);
            return array("message" => 'Successfully Logged in.', "status" => '1');
        } else {
            return array("message" => 'Login Failed! Id or Password Invalid.', "status" => '0');
        }
    }

    public function getChildernByParentId($parentId)
    {
        $this->db->select('u.id, u.firstName, u.lastName,u.userName,u.balance,c.parentId');
        $this->db->from('child c');
        $this->db->join('user u', 'u.id = c.childId');
        $this->db->where('c.parentId', $parentId);
        $this->db->order_by('id', 'desc');
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }

    public function getGoalByChildId($childId)
    {
        $this->db->select('*');
        $this->db->where('childId', $childId);
        $this->db->order_by('id', 'desc');
        $query = $this->db->get('goal');

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }



    public function getProducts()
    {
        $query = $this->db->order_by('id', 'DESC')->get('product');
        return $query->result_array();
    }

    public function updateProfile($data)
    {
        $userId = $this->session->userdata('id');

        // Prepare the data to be updated
        $updateData = array(
            'firstName' => $data['firstName'],
            'lastName' => $data['lastName'],
            'dob' => $data['dob'],
            // 'email' => $data['email'],
               'shippingAddress' => isset($data['shippingAddress'])?$data['shippingAddress']:''
        );

        // Check if Id is set and needs to be updated
        if (isset($data['userName'])) {
            // Check if the new Id already exists in the database
            $this->db->where('userName', $data['userName']);
            $this->db->where('id !=', $userId); // Exclude the current user
            $query = $this->db->get('user');

            if ($query->num_rows() > 0) {
                return array("message" => "Id already exists.", "status" => "0");
            } else {
                $updateData['userName'] = $data['userName'];
            }
        }

        // Check if password is set and needs to be updated
        if (!empty($data['pass'])) {
            $updateData['pass'] = md5($data['pass']);
        }

        // Perform the update
        $this->db->where('id', $userId);
        $update = $this->db->update('user', $updateData);

        if ($update) {
            return array("message" => "Profile successfully updated.", "status" => "1");
        } else {
            return array("message" => "Update failed.", "status" => "0");
        }
    }



    public function insertRemindersForGoal($userId)
    {
        // Retrieve all goals for the given user ID
        $this->db->where('childId', $userId);
        $this->db->where('startDate <=', date('Y-m-d'));
        $goals = $this->db->get('goal')->result_array();

        // Get the current date
        $currentDate = new DateTime();
        $currentWeek = $currentDate->format("W");
        $currentMonth = $currentDate->format("m");

        // Iterate through each goal
        foreach ($goals as $goal) {
            $goalId = $goal['id'];
            $planType = $goal['goalPlanType'];
            $planTypeComplete = $planType;
            $targetAmount = $goal['targetAmount'];
            $goalAmount = $goal['goalAmount'];
            $updatedDate = isset($goal['updatedDate']) ? new DateTime($goal['updatedDate']) : null;

            // Validate planType contains a valid keyword
            $planTypeKeywords = ['Daily', 'Weekly', 'Monthly'];
            $containsValidKeyword = false;
            foreach ($planTypeKeywords as $keyword) {
                if (stripos($planType, $keyword) !== false) {
                    $containsValidKeyword = true;
                    $planType = $keyword; // Use the keyword for comparison
                    break;
                }
            }

            if (!$containsValidKeyword) {
                continue; // Skip invalid plan types
            }

            // Check if targetAmount is less than goalAmount
            if ($targetAmount <= $goalAmount) {
               // echo "Skipping goal $goalId because targetAmount is greater than or equal to goalAmount<br>";
                continue; // Skip if the target amount is not less
            }

            // Check if reminder already exists for the same date and goal
            $this->db->where('goalId', $goalId);
            $this->db->where('planType', $planTypeComplete);
            $this->db->where('DATE(createdDate)', $currentDate->format('Y-m-d'));
            $existingReminder = $this->db->get('reminder')->row_array();

            if ($existingReminder) {
                continue; // Skip if a reminder already exists
            }

            // Check updatedDate based on the planType
            $addReminder = false;

            if ($updatedDate === null) {
                // Add reminder if updatedDate is null
                $addReminder = true;
            } else {
                switch ($planType) {
                    case 'Daily':
                        if ($updatedDate->format('Y-m-d') != $currentDate->format('Y-m-d')) {
                            $addReminder = true;
                        }
                        break;
                    case 'Weekly':
                        if ($updatedDate->format('W') != $currentWeek) {
                            $addReminder = true;
                        }
                        break;
                    case 'Monthly':
                        if ($updatedDate->format('m') != $currentMonth) {
                            $addReminder = true;
                        }
                        break;
                }
            }

            if ($addReminder) {
                $data = [
                    'goalId'       => $goalId,
                    'planType'     => $planTypeComplete,
                    'createdDate'  => $currentDate->format('Y-m-d H:i:s'),
                ];
                $this->db->insert('reminder', $data);
            }
        }

        return "Reminders added successfully!";
    }
}
