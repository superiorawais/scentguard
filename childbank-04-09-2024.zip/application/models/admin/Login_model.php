<?php

Defined('BASEPATH') or exit('No direct script access allowed');

class Login_model extends CI_Model
{

    public function login($data)
    {
        $userName = $data['userName'];
        $pass = $data['pass'];

        $this->db->where('user_name', $userName);
        $this->db->where('pass', md5($pass));
        $this->db->where('status', '1');
        $query = $this->db->get('panel_user');

        //echo $this->db->last_query();

        if ($query->num_rows() > 0) {
            $result = $query->row_array();

            $this->session->set_userdata('user_id', $result['id']);
            $this->session->set_userdata('panel_user_id', $result['id']); // for login check
            $this->session->set_userdata('name', $result['user_name']);
            $response = array("message" => 'Successfully Login.', "status" => '1');
        } else {
            $response = array("message" => 'Login Failed.', "status" => '0');
        }
       return $response;
    }
}
