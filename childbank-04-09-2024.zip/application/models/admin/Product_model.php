<?php

Defined('BASEPATH') or exit('No direct script access allowed');

class Product_model extends CI_Model
{

    function getProducts()
    {
        $this->db->order_by('id', 'DESC');
        $query = $this->db->get('product');
        $result = $query->result_array();
        return $result;
    }

    public function add($data)
    {
        $name = ucfirst($data['name']);
        $image = !empty($data['image']) ? $data['image'] : '';
        $price = $data['price'];
        $description = $data['description'];
        $dataToInsert = array(
            'name' => $name,
            'price' => $price,
            'description' => $description,
            'image' => $image
        );
        $insert = $this->db->insert('product', $dataToInsert);
        if ($insert) {
            $response = array("message" => "Product Successfully Added.", "status" => "1");
        } else {
            $response = array("message" => "Operation Failed.", "status" => "0");
        }
       return $response;
    }
    
    public function getSpecificProduct($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('product');
        $result = $query->result_array();
        return $result;
    }

    function edit($data)
    {
        $id = $data['id'];
         $name = ucfirst($data['name']);
         $image = !empty($data['image']) ? $data['image'] : '';
         $price = $data['price'];
         $description = $data['description'];
         $dataToUpdate = array(
             'name' => $name,
             'price' => $price,
             'description' => $description,
             'image' => $image
         );
         $this->db->where('id', $id);
         $update = $this->db->update('product', $dataToUpdate);
         if ($update) {
             $response = array("message" => "Product Successfully Updated.", "status" => "1");
         } else {
             $response = array("message" => "Operation Failed.", "status" => "0");
         }
         return $response;
    }

    public function status($id, $status)
    {
        $data = array(
            'status' => $status
        );
        
        $this->db->where('id', $id);
        $query = $this->db->update('product', $data);

        if ($query) {
            return array("message" => "Product Successfully Updated.", "status" => "1");
        } else {
            return array("message" => "Operation Failed.", "status" => "0");
        }
    }

    function del($id)
    {

       $this->db->where('id', $id);
       $query = $this->db->delete('product');

       if ($query) {
           return array("message" => "Product Successfully Deleted.", "status" => "1");
       } else {
           return array("message" => "Operation Failed.", "status" => "0");
       }
    }
}
