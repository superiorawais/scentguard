<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Product extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('admin/Product_model');
    }

    function index()
    {
        if (isUserLogin())
            $this->loadProductView();
    }

    function loadProductView()
    {
        if (isUserLogin())

            $this->template->set_layout('adminTemplate')->build('admin/product_view', '');
    }

    public function add()
    {
        $data = '';
        $config['upload_path'] = './uploads/product/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg|webp';
        $config['max_size'] = 1024;

        $this->load->library('upload', $config);

        if (!empty($_FILES['image']['name'])) {
            if (!$this->upload->do_upload('image')) {
                $error = $this->upload->display_errors('', '');
                echo json_encode(array("message" => $error, "status" => "0"));
                exit;
            } else {
                $data = $this->upload->data();
                $data = $data['file_name'];
            }
        } else {
            $data = '';
        }

        $formData = $this->input->post();
        $formData['image'] = $data;
        $response = $this->Product_model->add($formData);
        echo json_encode($response);
    }

    function getProducts()
    {
        $response = $this->Product_model->getProducts();
        echo json_encode($response);
    }

    function getSpecificProduct()
    {
        $id = $this->input->post('ID');
        $response = $this->Product_model->getSpecificProduct($id);
        echo json_encode($response);
    }

    function edit()
    {
        $config['upload_path'] = './uploads/product/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg|webp';
        $config['max_size'] = 1024;
        $this->load->library('upload', $config);

        // Handle the image upload
        if (!empty($_FILES['image']['name'])) {
            if (!$this->upload->do_upload('image')) {
                $error = $this->upload->display_errors();
                $error = strip_tags($error); // Remove HTML tags
                echo json_encode(array("message" => $error, "status" => "0"));
                exit;
            } else {
                $uploadedData = $this->upload->data();
                $imageFileName = $uploadedData['file_name'];
            }
        } else {
            $imageFileName = $this->input->post('image'); // Use the existing image if no new image is uploaded
        }

        $formData = $this->input->post();
        $formData['image'] = $imageFileName;
        $response = $this->Product_model->edit($formData);
        echo json_encode($response);
    }

    function status()
    {
        $id = $this->input->post('ID');
        $status = $this->input->post('STATUS');
        $response = $this->Product_model->status($id, $status);
        echo json_encode($response);
    }

    function del()
    {
        $id = $this->input->post('ID');
        $response = $this->Product_model->del($id);
        echo json_encode($response);
    }
}
